class WiFi(object):
    def __init__(self):
        """ load the required modules into the project """  
        self.esp32_SCK  =""
        self.esp32_MOSI =""
        self.esp32_MISO =""
        self.esp =""
        self.wifi =""
        self.socket = ""
        import adafruit_esp32spi.adafruit_esp32spi_socket as socket
        self.socket = socket
        from wifi.secrets import secrets
        self.secrets = secrets

        
    def connect(self):
        try:
            from WiFi.secrets import secrets
        except ImportError:
            print("WiFi secrets are kept in secrets.py, please add them there!")
            raise
        import board
        import busio
        from digitalio import DigitalInOut
        # import the scripts to correctly un the WiFi Module
        from adafruit_esp32spi import adafruit_esp32spi
        # import the scripts to correctly un the WiFi Module
        from adafruit_esp32spi import adafruit_esp32spi
        from adafruit_esp32spi import adafruit_esp32spi_wifimanager
        # Set the IO pin connections for the WiFi Unit
        esp32_cs = DigitalInOut(board.GP15)
        esp32_ready = DigitalInOut(board.GP13)
        esp32_reset = DigitalInOut(board.GP14)

        self.esp32_SCK = board.GP10  # configure Piboard's pin for system clock (speed)
        self.esp32_MOSI = board.GP11 # configure Piboard's pin for Master Out, Slave In, Data transmission from a Host to Device
        self.esp32_MISO = board.GP12 # configure Piboard's pin for Master In, Slave Out, Data transmission from a Device to Host.
        spi = busio.SPI(self.esp32_SCK, self.esp32_MOSI, self.esp32_MISO)# SPI is a serial protocol that has exclusive pins for data in and out of the main device.
        self.esp = adafruit_esp32spi.ESP_SPIcontrol(spi, esp32_cs, esp32_ready, esp32_reset)# controlling the WiFi unit
        self.wifi = adafruit_esp32spi_wifimanager.ESPSPI_WiFiManager(self.esp, self.secrets) # wifi == the connection to the module

        
    #--------------------------------------------
    # Set up WiFi connection to internet and return the socket and device variables
    #--------------------------------------------   
    def connectToSite(self):
        # Connect to WiFi
        self.connect()
        connectionData= [self.esp, self.socket]
        return connectionData
    #--------------------------------------------
    def connectToWiFi(self):
        wifiLinks = self.connectToSite()
        wifiModule = wifiLinks[0]
        #-----------------------------------------------------------------
        # attempt to connect to the secure website
        #-----------------------------------------------------------------
        while not wifiModule.is_connected:
            try:
                # the AP connection's details
                wifiModule.connect_AP(self.secrets["ssid"], self.secrets["password"])
                print("returning the requests")

            except RuntimeError as e:
                print("could not connect to AP, retrying: ", e)
                continue # repeat try...
        return wifiLinks # return TCP socket and Wifi Module data for the project to use

