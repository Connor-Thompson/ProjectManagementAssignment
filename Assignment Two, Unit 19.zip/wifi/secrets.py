
secrets = {
   'ssid' : 'VM7400004',
   'password' : 'ty8Yfbjkn6cs',
   'aio_username' : 'Connor_JT',
   'aio_key' : 'aio_JxVM65vxI28wt0M8UEIaERl5NLuE',
   'timezone' : 'Europe/London', # http://worldtimeapi.org/timezones
   }

