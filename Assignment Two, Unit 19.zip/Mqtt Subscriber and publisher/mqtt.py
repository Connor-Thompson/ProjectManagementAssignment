""" -------------- MQTT Library      -----------------------
https://circuitpython.readthedocs.io/projects/adafruit-circuitpython-minimqtt/en/latest/api.html
 --------------------------------------------------------- """
class Mqtt(object):
    def __init__(self, tcpSocket, wifiModule, secretFile, subscriptions):
        self.mqttConnection = ""
        self.subscriptions = subscriptions # The given feeds subscribed to
        self.feedback = ["_","_"] #default feedback
        self.secrets = secretFile
        #-----------------------------------------------
        #  Set up MQTT connection with Broker (Adafruit.com)
        #-----------------------------------------------
        import adafruit_minimqtt.adafruit_minimqtt as MQTT
        #-----------------------------------------------
        #  Initialize MQTT interface with the wifi and secrets arguments
        #-----------------------------------------------
        MQTT.set_socket(tcpSocket, wifiModule)
        #   Set up a MQTT Client
        self.mqttConnection = MQTT.MQTT(
            broker="io.adafruit.com",
            username = self.secrets["aio_username"],
            password = self.secrets["aio_key"]
            )
    #-----------------------------------------------
    #  Callback function will be called when the client successfully connects to the broker.
    #-----------------------------------------------
    def connected(self, client, userdata, flags, rc):
        if (len(self.subscriptions) > 0):
            # Subscribe to the feeds provided
            for feed in self.subscriptions:
                client.subscribe(self.secrets["aio_username"] + feed)
                print("Connected to Adafruit IO! Listening for topic changes on %s" % self.secrets["aio_username"] + feed)
        else:
            print("Connected to Adafruit IO!")
    #-----------------------------------------------
    #  Callback function is called when a message is received
    #-----------------------------------------------
    def message(self,client, topic, message):
        print("New message on topic {0}: {1}".format(topic, message))        
        for feed in self.subscriptions:
            if topic == (self.secrets["aio_username"] + feed):
                self.feedback = [topic, message]
                break
    #-----------------------------------------------
    #  Callback function is called when the client is disconnected
    #-----------------------------------------------
    def disconnected(self,client, userdata, rc):
        print("Disconnected from Adafruit IO!")
    #-----------------------------------------------
    # create the connection  
    #-----------------------------------------------  
    def connection(self):
        #-----------------------------------------------
        #  MQTT Setup for the callback methods above
        #-----------------------------------------------
        self.mqttConnection.on_connect = self.connected
        self.mqttConnection.on_disconnect = self.disconnected
        self.mqttConnection.on_message = self.message
        #-----------------------------------------------
        #  Connect the client to the MQTT broker.
        #-----------------------------------------------
        print("Connecting to Adafruit IO...")
        self.mqttConnection.connect()
    #-----------------------------------------------
    # Send the data to the Broker
    #-----------------------------------------------
    #def publishData(self, publisherLink, theData):
    #    self.mqttConnection.publish(publisherLink, theData)   
    #-----------------------------------------------
    # Send the data to the Broker
    #-----------------------------------------------
    def publishData(self, publisherLink, theData, *argv):
        try:
            qosIn = argv[0]
            qosLevel = int(qosIn[len(qosIn)-1:len(qosIn)])
            if(qosLevel > 1):
                qosLevel = 0
                pass
        except:
            qosLevel = 0            
        return self.mqttConnection.publish(publisherLink, theData, qos=qosLevel)       
    #-----------------------------------------------
    # Send the data to the Broker
    #-----------------------------------------------
    def checkForUpdates(self):
        if(self.mqttConnection.loop()):
            return self.feedback
#-----------------------------------------------

