#-----------------------------------------------
#  load the required modules into the project
#-----------------------------------------------
import time # to apply a time delay
import microcontroller # to read core temperature
from wifi.secrets import secrets # to access AdaFruit account
from mqtt import mqtt # to access mqtt publish/subscribe processes
print("Starting project connecting to Access Point")
#-----------------------------------------------
# Create connect to the wifi access point
#-----------------------------------------------
from wifi import wifiConnectClass
myWiFi_Obj  = wifiConnectClass.WiFi()
wifiLinks = myWiFi_Obj.connectToWiFi()
#-----------------------------------------------
# Use WiFi links to open an MQTT link
#-----------------------------------------------
subscriptions = []
mqtt_Obj  = mqtt.Mqtt(wifiLinks[1], wifiLinks[0], secrets, subscriptions)
#-----------------------------------------------
#Connect to the target using MQTT
#-----------------------------------------------
mqtt_Obj.connection()
#-----------------------------------------------
#  Link as Publisher to AdaFruit using secret's account data
#-----------------------------------------------
publisherLink = secrets["aio_username"] + "/feeds/coreTemperature"
#-----------------------------------------------
run = True    # Controls the while loop -> False end the loop
QoS = "qos=1"       # Set the QoS level
#-----------------------------------------------
#  Loop to continually send MQTT messages
#-----------------------------------------------
print("-" * 40)
print("Connecting with quality set to " + QoS)
print("-" * 40)
while run:
    result = mqtt_Obj.checkForUpdates() # Run the callback message if it receives data.
    # Read microcontroller's core temperature
    coreTemp = microcontroller.cpu.temperature
    # Publish the latest temperature to the Broker
    print("Sending temperature: " + str(coreTemp) + chr(176) + "C")
    # send the data with QoS level as "qos=1" or "qos=0"
    qosReply = mqtt_Obj.publishData(publisherLink, coreTemp,QoS)
    if(QoS == "qos=1"):
        print("  ..." + str(qosReply)) # if QoS 1 then print the result
    print("-" * 40)
    time.sleep(2)
print("*** Project has been reset ***")
