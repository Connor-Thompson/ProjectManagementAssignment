#-----------------------------------------------
#  load the required modules into the project
#-----------------------------------------------
import time # to apply a time delay
import microcontroller # to read core temperature
from wifi.secrets import secrets # to access AdaFruit account
from mqtt import mqtt # to access mqtt publish/subscribe processes
#-----------------------------------------------
# Create connect to the wifi access point
#-----------------------------------------------
from wifi import wifiConnectClass
myWiFi_Obj  = wifiConnectClass.WiFi()
wifiLinks = myWiFi_Obj.connectToWiFi()
#-----------------------------------------------
# Use WiFi links to open an MQTT link
#-----------------------------------------------
subscriptions = []
mqtt_Obj  = mqtt.Mqtt(wifiLinks[1], wifiLinks[0], secrets, subscriptions)
#-----------------------------------------------
#Connect to the target using MQTT
#-----------------------------------------------
mqtt_Obj.connection()
#-----------------------------------------------
#  Link as Publisher to AdaFruit using secret's account data
#-----------------------------------------------
publisherLink = secrets["aio_username"] + "/feeds/coreTemperature"
#-----------------------------------------------
#  Loop to continually send MQTT messages
#-----------------------------------------------
while True:    
    coreTemp = microcontroller.cpu.temperature
    #-----------------------------------------------
    # Publish the latest core temperature to the Broker
    #-----------------------------------------------
    print("Sending core temperature: %d..." %coreTemp )
    mqtt_Obj.publishData(publisherLink, coreTemp)
    print("Sent!")
    time.sleep(5)
