import board
import busio
from digitalio import DigitalInOut
import adafruit_requests as requests
import adafruit_esp32spi.adafruit_esp32spi_socket as socket
from adafruit_esp32spi import adafruit_esp32spi
from secrets import secrets

print("Raspberry Pi Pico WiFi Weather Station")
JSON_URL = "http://api.openweathermap.org/data/2.5/weather?q=Gainsborough&appid=a10dfa0c89fabe381038fff70f73480b&units=metric"
 
esp32_cs = DigitalInOut(board.GP15)
esp32_ready = DigitalInOut(board.GP13)
esp32_reset = DigitalInOut(board.GP14)

esp32_SCK = board.GP10
esp32_MOSI = board.GP11
esp32_MISO = board.GP12

spi = busio.SPI(esp32_SCK, esp32_MOSI, esp32_MISO)
esp = adafruit_esp32spi.ESP_SPIcontrol(spi, esp32_cs, esp32_ready, esp32_reset)
 
requests.set_socket(socket, esp)
 
while not esp.is_connected:
    try:
        esp.connect_AP(secrets["ssid"], secrets["password"])
    except RuntimeError as e:
        print("could not connect to AP, retrying: ", e)
        continue
print("Fetching weather data")
r = requests.get(JSON_URL)
print(r.status_code)
print("-" * 40)
print("The current temperature is",r.json()['main']['temp_max'],"C")
print("-" * 40)
r.close()
