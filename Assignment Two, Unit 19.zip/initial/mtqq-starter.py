# SPDX-FileCopyrightText: 2021 ladyada for Adafruit Industries
# SPDX-License-Identifier: MIT

import time
import board
import busio
from digitalio import DigitalInOut
import digitalio
import microcontroller

#Adafruit so=pecific modules
from adafruit_esp32spi import adafruit_esp32spi
from adafruit_esp32spi import adafruit_esp32spi_wifimanager
import adafruit_esp32spi.adafruit_esp32spi_socket as socket #can be accessed via the 'socket.' selector

import adafruit_minimqtt.adafruit_minimqtt as MQTT #can be accessed via the 'MQTT.' selector

#
led = DigitalInOut(board.LED)
led.direction = digitalio.Direction.OUTPUT
led.value = True
run = True
### WiFi ###

# Get wifi details and more from a secrets.py file use 'try' as the file may not open!
try:
    from secrets import secrets
except ImportError:
    print("WiFi secrets are kept in secrets.py, please add them there!")
    led.value = False
    raise
#esp == adafruit connection
esp32_cs = DigitalInOut(board.GP15)
esp32_ready = DigitalInOut(board.GP13)
esp32_reset = DigitalInOut(board.GP14)

esp32_SCK = board.GP10
esp32_MOSI = board.GP11
esp32_MISO = board.GP12

spi = busio.SPI(esp32_SCK, esp32_MOSI, esp32_MISO)
esp = adafruit_esp32spi.ESP_SPIcontrol(spi, esp32_cs, esp32_ready, esp32_reset)
wifi = adafruit_esp32spi_wifimanager.ESPSPI_WiFiManager(esp, secrets)

### Feeds ###

# Setup a feed named 'temp_feed' for publishing to a feed
temp_feed = secrets["aio_username"] + "/feeds/temp_feed"

# Setup a feed named 'onoff' for subscribing to changes
onoff_feed = secrets["aio_username"] + "/feeds/onoff"

# Setup a feed named 'onoff' for subscribing to changes
quit_feed = secrets["aio_username"] + "/feeds/quit"


### Code ###

# Define callback methods which are called when events occur
# pylint: disable=unused-argument, redefined-outer-name
def connected(client, userdata, flags, rc):
    # This function will be called when the client is connected
    # successfully to the broker.
    print("Connected to Adafruit IO! Listening for topic changes on %s" % onoff_feed)
    # Subscribe to all changes on the onoff_feed.
    client.subscribe(onoff_feed)
    client.subscribe(quit_feed)


def disconnected(client, userdata, rc):
    # This method is called when the client is disconnected
    print("Disconnected from Adafruit IO!")


def message(client, topic, message):
    # This method is called when a topic the client is subscribed to
    # has a new message.
    global run
    print("New message on topic {0}: {1}".format(topic, message))
    if topic == onoff_feed and message == 'ON' :
        led.value = True
    if topic == onoff_feed and message == 'OFF' :
        led.value = False
    if topic == quit_feed and message == 'stop' :
        led.value = False
        run = False

# Connect to WiFi
print("Connecting to WiFi...")
wifi.connect()
print("Connected!")

# Initialize MQTT interface with the esp interface
MQTT.set_socket(socket, esp)

# Set up a MiniMQTT Client
mqtt_client = MQTT.MQTT(
    broker="io.adafruit.com",
    username=secrets["aio_username"],
    password=secrets["aio_key"],
)

# Setup the callback methods above
mqtt_client.on_connect = connected
mqtt_client.on_disconnect = disconnected
mqtt_client.on_message = message

# Connect the client to the MQTT broker.
print("Connecting to Adafruit IO...")
mqtt_client.connect()

while run:
    # Poll the message queue
    mqtt_client.loop()
    temp = microcontroller.cpu.temperature
    # Send a new message
    print("Sending temperature: %d..." %temp )
    mqtt_client.publish(temp_feed, temp)
    print("Sent!")

    time.sleep(5)

