secrets2 = {
   'ssid' : 'Computing',
   'password' : '111MbTEPxU',
   'aio_username' : 'John_IT',
   'aio_key' : 'aio_SWqL050UZIf3bC46ZgSUBgFaBGwn',
   'timezone' : 'Europe/London', # http://worldtimeapi.org/timezones
   }

secrets = {
   'ssid' : 'netbios1',
   'password' : '1592-Usa-1@home',
   'aio_username' : 'John_IT',
   'aio_key' : 'aio_SWqL050UZIf3bC46ZgSUBgFaBGwn',
   'timezone' : 'Europe/London', # http://worldtimeapi.org/timezones
   }

# Maker Pi Pico info https://thepihut.com/products/maker-pi-pico-with-pre-soldered-pico