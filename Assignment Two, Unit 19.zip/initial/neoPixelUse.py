#---------------------------------------------
#get Modlues to use
import time # so you can use the time function
import board # get Maker PI Pico board module
import neopixel
#---------------------------------------------
# Set initial values
#---------------------------------------------
pixels = neopixel.NeoPixel(board.GP28, 1) # Set link for the onboard Neopixel 3 colour LED
pauseFor = 0.75 # Set time wait value
#---------------------------------------------
# Start project
#---------------------------------------------
print("Started 3-colour (neopixel) LED project")
#---------------------------------------------
# LOOP 3 times through the display
#---------------------------------------------
for x in range(2):
    # using function pixels(Red_int, Green_int, Blue_int)
    pixels[0] = (10, 0, 0) # red
    time.sleep(pauseFor)
    pixels[0] = (10, 10, 0)# Yellow
    time.sleep(pauseFor)
    pixels[0] = (0, 10, 0)# Green
    time.sleep(pauseFor)
    pixels[0] = (0, 10, 10)# Cyan
    time.sleep(pauseFor)
    pixels[0] = (0, 0, 10)# Blue
    time.sleep(pauseFor)
    pixels[0] = (10, 0, 10)# Purple
    time.sleep(pauseFor)
pixels[0] = (10, 10, 10)# White
time.sleep(pauseFor)
#---------------------------------------------
# Turn off LED and complete
#---------------------------------------------
pixels[0] = (0, 0, 0)# Black/Off         
print("The LED test is complete")