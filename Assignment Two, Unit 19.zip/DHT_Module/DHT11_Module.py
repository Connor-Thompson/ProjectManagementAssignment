class TempHumid(object):
    def __init__(self, groveNumber):
        import adafruit_dht
        import board
        self.Grove = None
        self.GroveNumber = groveNumber
        #Allow connection to any Grove connector
        if(groveNumber == 1):
            self.Grove = board.GP1
        elif(groveNumber == 2):
            self.Grove = board.GP3
        elif(groveNumber == 3):
            self.Grove = board.GP5
        elif(groveNumber == 4):
            self.Grove = board.GP7
        elif(groveNumber == 5):
            self.Grove = board.GP9
        elif(groveNumber == 6):
            self.Grove = board.GP27
        #Create the connection if the DHT is found
        if(self.Grove != None):
            self.dht = adafruit_dht.DHT11(self.Grove)
        else:
            return None
    #--------------------------------------------------       
    def getTemperature(self):
        try:
            return self.dht.temperature
        except:
            return "The sensor does not appear to be connected the Grove " + str(self.GroveNumber)
    #--------------------------------------------------  
    def getHumidity(self):
        try:
            return self.dht.humidity
        except:
            return "Check Grove number"
    #--------------------------------------------------  