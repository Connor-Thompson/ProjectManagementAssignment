#Connecting a light sensor to the Grove 6
# the ADCinput port.
import board
import analogio

class LuxSensor(object):
    def __init__(self):
        # Only Grove 6 connector contains an ADC
        self.light = analogio.AnalogIn(board.GP27)
    
    def getReading(self):
        return self.light.value


