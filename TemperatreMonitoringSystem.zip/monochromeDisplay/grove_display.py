import os
import busio
import board
import displayio
import terminalio
import adafruit_displayio_ssd1306
from adafruit_display_text import label

class BitmapDisplay(object):
    def __init__(self, groveNumber):
        #--------- for connection ------------
        self.dataLine = None
        self.clock = None
        self.i2c = None
        self.GroveNumber = groveNumber
        #---------- for display --------------
        self.bitmap_palette = None
        self.display_bus = None
        self.display = None
        self.textPosition = None
        self.elements_to_display = None
        #--------------------------------------
        #Allow connection to Grove connectors 1 or 2
        #--------------------------------------
        if(groveNumber == 1):
            self.dataLine = board.GP0
            self.clock = board.GP1
        elif(groveNumber == 2):
            self.dataLine = board.GP2
            self.clock = board.GP3
        #--------------------------------------
        if(self.dataLine != None):
            #----------------------------------
            # A connection established
            #----------------------------------
            self.i2c = busio.I2C(self.clock, self.dataLine)
            self.i2c.unlock()
            if(self.i2c.try_lock()):
                self.i2c.unlock()
            self.bitmap_palette = displayio.Palette(2)
            self._setPalette()
            self.elements_to_display = displayio.Group()
        else:
            #----------------------------------
            # Connection failed
            #----------------------------------
            return None
    """ ======================================= """
    def __del__(self):
        # body of destructor
        self.closeDisplay()
        displayio.release_displays()
        self.i2c.deinit()
    """ ======================================= """
    def show(self, elementArray):
        try:
            if(self.display == None):
                display_bus = displayio.I2CDisplay(self.i2c, device_address=60)
                self.display = adafruit_displayio_ssd1306.SSD1306(display_bus, width=128, height=64)
                
            return self.display.show(elementArray)
        except OSError:
            return self.display.show(elementArray)
    """ ======================================= """
    def closeDisplay(self):
        displayio.release_displays()
        self.i2c.unlock()
        self.i2c.deinit()
    """ ======================================= """
    def _setPalette(self):
        self.bitmap_palette[0] = 0x000000
        self.bitmap_palette[1] = 0xffffff
    """ ======================================= """
    def addLine(self, width, height, xWidth, yHeight):
        lineToAdd = displayio.Bitmap(width, height, 2)
        lineGrid =  displayio.TileGrid(lineToAdd, pixel_shader=self.bitmap_palette, x=xWidth, y=yHeight)
        self.elements_to_display.append(lineGrid)
        lineToAdd.fill(1)
    """ ======================================= """
    def removeLine(self, xPos, yPos):
        try:
            keep = []
            for i in range(len(self.elements_to_display)):
                last = self.elements_to_display.pop()
                if str(type(last)) == "<class 'TileGrid'>":
                    if not(last.x == xPos and last.y == yPos):
                        keep.append(last)
                if str(type(last)) == "<class 'Group'>":
                    keep.append(last)
            for x in keep:
                self.elements_to_display.append(x)
        except:
            pass
    """ ======================================= """
    def addLabel(self, textToDisplay, scaleOf, xPos, yPos):
        textLabel = label.Label(terminalio.FONT, text=textToDisplay, color=0xffffff)
        self.textPosition = displayio.Group(scale=scaleOf, x=xPos, y=yPos)
        self.textPosition.append(textLabel)
        self.elements_to_display.append(self.textPosition)
        self.show(self.elements_to_display)
    """ ======================================= """
    def updateLastLabel(self, textToSet):
        try:
            self.textPosition[0].text=textToSet
            self.show(self.elements_to_display)
        except:
            print("error")
    """ ======================================= """
    def removeLabel(self, xPos, yPos):
        try:
            keep = []
            for i in range(len(self.elements_to_display)):
                last = self.elements_to_display.pop()
                if str(type(last)) == "<class 'Group'>":
                    if not(last.x == xPos and last.y == yPos):
                        keep.append(last)
                if str(type(last)) == "<class 'TileGrid'>":
                    keep.append(last)
            for x in keep:
                self.elements_to_display.append(x)
        except:
            pass
    """ ======================================= """
    def replaceLabel(self, oldXpos, oldYpos, textToDisplay, scaleOf, xPos, yPos):
        try:
            self.removeLabel(oldXpos, oldYpos)
            self.addLabel(textToDisplay, scaleOf, xPos, yPos)
        except:
            print("error")
    """ ======================================= """
    def clearScreen(self):
        try:
            for i in range(len(self.elements_to_display)):
                self.elements_to_display.pop()
        except:
            pass
    """ ======================================= """



