#-----------------------------------------------
#  load the required modules into the project
#-----------------------------------------------
import time # to apply a time delay
import microcontroller # to read core temperature
from wifi.secrets import secrets # to access AdaFruit account
from mqtt import mqtt # to access mqtt publish/subscribe processes
from neoPixel_device import board_neoPixel
neoPixel = board_neoPixel.neoPixel()
#-----------------------------------------------
# Create connect to the wifi access point
#-----------------------------------------------
from wifi import wifiConnectClass
myWiFi_Obj  = wifiConnectClass.WiFi()
wifiLinks = myWiFi_Obj.connectToWiFi()
#-----------------------------------------------
# Use WiFi links to open an MQTT link
#-----------------------------------------------
subscriptions = ["/feeds/onoff","/feeds/quit"]
mqtt_Obj  = mqtt.Mqtt(wifiLinks[1], wifiLinks[0], secrets, subscriptions)
#-----------------------------------------------
#Connect to the target using MQTT
#-----------------------------------------------
mqtt_Obj.connection()
#-----------------------------------------------
#  Link as Publisher to AdaFruit using secret's account data
#-----------------------------------------------
publisherLink = secrets["aio_username"] + "/feeds/coreTemperature"
#-----------------------------------------------
run = True    # Controls the while loop -> False end the loop
pause = False # Prevents publishing of the temperature
#-----------------------------------------------
#  Loop to continually send MQTT messages
#-----------------------------------------------
while run:
    result = mqtt_Obj.checkForUpdates() # Run the callback message if it receives data.
    # React to any new message received
    if(result != None):
        if(result[1] == "Pause"):
            pause = True
            print("Paused")
        if(result[1] == "Run"):
            pause = False
        if(result[1] == "Stop"):
            run = False
            neoPixel.off()
        if(result[1] == "alarm"):
            neoPixel.setRed()
        # The publish script
    elif(not pause):
        coreTemp = microcontroller.cpu.temperature
        # Publish the latest temperature to the Broker
        print("Sending temperature: %d..." %coreTemp )
        mqtt_Obj.publishData(publisherLink, coreTemp)
        print("Sent!")
        # set a short pause for checking subscriptions and publishing loop
    time.sleep(2)
print("*** Project has been reset ***")
