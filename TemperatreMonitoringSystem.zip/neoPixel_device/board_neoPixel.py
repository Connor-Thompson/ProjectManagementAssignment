#---------------------------------------------
#get Modules to use
import time # so you can use the time function
import board # get Maker PI Pico board module

from lib import neopixel # for the LED device
#---------------------------------------------
# Set link for the onboard Neopixel 3 colour LED
# This is the General Purpose I/O pin 28 
#---------------------------------------------
class neoPixel(object):
    def __init__(self):
        #--------- for connection ------------
        self.light = neopixel.NeoPixel(board.GP28, 1)
    """ ======================================= """
    def setColour(self, red, green, blue):
        self.light[0] = (red, green, blue)
    """ ======================================= """
    def setRed(self):
        self.light[0] = (20,0,0)
    """ ======================================= """
    def setGreen(self):
        self.light[0] = (0,20,0)
    """ ======================================= """
    def setBlue(self):
        self.light[0] = (0,0,20)
    """ ======================================= """
    def setYellow(self):
        self.light[0] = (20,20,0)
    """ ======================================= """
    def setCyan(self):
        self.light[0] = (0,20,20)
    """ ======================================= """
    def setPurple(self):
        self.light[0] = (20,0,20)
    """ ======================================= """
    def setWhite(self):
        self.light[0] = (20,20,20)
    """ ======================================= """
    def off(self):
        self.light[0] = (0,0,0)
    """ ======================================= """
        
        
        
        
        
        
