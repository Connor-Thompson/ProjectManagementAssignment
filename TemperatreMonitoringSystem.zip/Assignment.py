#-----------------------------------------------
#  load the required modules into the project
#-----------------------------------------------
import os
import time
import board
import digitalio
from monochromeDisplay import grove_display

display = grove_display.BitmapDisplay(1)
#import microcontroller # to read core temperature
from piBuzzer import buzzerOut
piezoBuzzer = buzzerOut.Buzzer()

from adafruit_debouncer import Debouncer

relay = digitalio.DigitalInOut(board.GP7)
relay.direction = digitalio.Direction.OUTPUT
from wifi.secrets import secrets # to access AdaFruit account
from DHT_Module import DHT11_Module
from mqtt import mqtt # to access mqtt publish/subscribe processes
from neoPixel_device import board_neoPixel
neoPixel = board_neoPixel.neoPixel()
#-----------------------------------------------
# Create connect to the wifi access point
#-----------------------------------------------
from wifi import wifiConnectClass
myWiFi_Obj  = wifiConnectClass.WiFi()
wifiLinks = myWiFi_Obj.connectToWiFi()

tempUnit = DHT11_Module.TempHumid(5)
#-----------------------------------------------
# Use WiFi links to open an MQTT link
#-----------------------------------------------
subscriptions = ["/feeds/onoff","/feeds/quit", "/feeds/Relay"]
mqtt_Obj  = mqtt.Mqtt(wifiLinks[1], wifiLinks[0], secrets, subscriptions)
#-----------------------------------------------
#Connect to the target using MQTT
#-----------------------------------------------
mqtt_Obj.connection()
#-----------------------------------------------
#  Link as Publisher to AdaFruit using secret's account data
#-----------------------------------------------
publisherLink = secrets["aio_username"] + "/feeds/coreTemperature"
#-----------------------------------------------
run = True    # Controls the while loop -> False end the loop
pause = False
# Prevents publishing of the temperature
#-----------------------------------------------
#  Loop to continually send MQTT messages
#-----------------------------------------------
while run:
    result = mqtt_Obj.checkForUpdates() # Run the callback message if it receives data.
    # React to any new message received
    if(result != None):
        if(result[1] == "Pause"):
            pause = True
            display.closeDisplay()
            print("Paused")
        if(result[1] == "Run"):
            pause = False
            display = grove_display.BitmapDisplay(1)
        if(result[1] == "Stop"):
            run = False
            neoPixel.off()
        if(result[1] == "On"):
            neoPixel.setRed()
            relay.value = 1
        #show relay position (although you should see its led!)
            output = "relay on"
            print(output)
        if(result[1] == "Off"):
            neoPixel.off()
            output = "relay off"
            relay.value = 0
            print(output)
        # The publish script
    elif(not pause):
        temperature = tempUnit.getTemperature()
        # Publish the latest temperature to the Broker
        print("Sending temperature: "  + str(temperature ))
        mqtt_Obj.publishData(publisherLink, temperature)
        print("Sent!")
        # set a short pause for checking subscriptions and publishing loop
    time.sleep(2)
    
    if temperature >= 20:
        ("Alarm activated!")
        neoPixel.setBlue()
        time.sleep(0.5)
        neoPixel.setRed()
        time.sleep(0.5)
        neoPixel.setBlue()
        time.sleep(0.5)
        neoPixel.setRed()
        neoPixel.off()
        print("")
        piezoBuzzer.setPitch(2)
        piezoBuzzer.setVolume(4)
        piezoBuzzer.setTempo(0.15)
        tune1 = ['B7', 'E7', 'B7', 'E7']
        piezoBuzzer.play_tone(tune1)
        display.addLabel(str(temperature), 1, 10, 6)
        time.sleep(2)
        display.clearScreen()
        
    elif temperature > 0:
        display.addLabel(str(temperature), 1, 10, 6)
        time.sleep(2)
        display.clearScreen()
    else:
        print("")
print("*** Project has been reset ***")


